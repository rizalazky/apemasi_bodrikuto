<div class="vbox wb_container" style="background:transparent;height:300px;margin-left:-90px;">
	<div id="wb_element_instance514" class="wb_element">
		<div>

		</div>
	</div>
	<div id="wb_element_instance515" class="wb_element" style=" line-height: normal;">
		<h3 class="wb-stl-heading3" style="text-align: center;"><strong>SKEMA DISTRIBUSI AIR DAERAH IRIGASI
				PADUREKSO</strong></h3>
	</div>
	<div id="wb_element_instance516" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>Sungai&nbsp;</strong></p>
	</div>
	<div id="wb_element_instance517" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>Areal</strong></p>
	</div>
	<div id="wb_element_instance518" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>:&nbsp; Sungai Sengkarang</strong></p>
	</div>
	<div id="wb_element_instance519" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>:&nbsp; 2.388,00 Ha</strong></p>
	</div>
	<div id="wb_element_instance520" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>Lokasi&nbsp;</strong></p>
	</div>
	<div id="wb_element_instance521" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>:&nbsp; Karanganyar,Pekalongan</strong></p>
	</div>
	<div id="wb_element_instance522" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>Periode</strong></p>
	</div>
	<div id="wb_element_instance523" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal" id='periode'></p>
	</div>
	<div id="wb_element_instance524" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal" style="text-align: center;"><strong>Debit Tersedia</strong></p>
	</div>
	<div id="wb_element_instance525" class="wb_element">
		<div></div>
	</div>
	<div id="wb_element_instance526" class="wb_element">
		<div></div>
	</div>
	<div id="wb_element_instance527" class="wb_element" style="margin-top:5px;">
		<div></div>
	</div>
	<div id="wb_element_instance528" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal" style="text-align: center;"><strong>Debit Diperlukan</strong></p>
	</div>
	<div id="wb_element_instance529" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal" style="text-align: center;"><strong>Faktor K</strong></p>

		<p class="wb-stl-normal" style="text-align: center;"><strong>ditetapkan</strong></p>
	</div>
	<div id="wb_element_instance530" class="wb_element" style=" line-height: normal;">
		<h4 class="wb-stl-pagetitle" id="debittersedia" style="text-align: right;">64.44</h4>
	</div>
	<div id="wb_element_instance531" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal">
			<strong>m3/dtk</strong>
		</p>
	</div>
	<div id="wb_element_instance532" class="wb_element" style=" line-height: normal;">
		<h4 class="wb-stl-pagetitle" id="debitdiperlukan" style="text-align: right;">4.44</h4>
	</div>
	<div id="wb_element_instance533" class="wb_element" style=" line-height: normal;">
		<p class="wb-stl-normal"><strong>m3/dtk</strong></p>
	</div>
	<div id="wb_element_instance534" class="wb_element" style=" line-height: normal;">
		<h1 class="wb-stl-heading1" id="faktorK" style="text-align: center;"></h1>
	</div>
	<div id="wb_element_instance535" class="wb_element"><img alt="f598400e35acc1b78bed66921344964e_190x120" src="../assets/images/asemsiketek.jpg">
		<!-- <script type="text/javascript">
			$("#wb_element_instance535").fancybox({
				href: "gallery_gen/1d4329a1f7ad3d40fbd720a4e2910981_fancybox.png",
				"hideOnContentClick": true
			});
		</script> -->
	</div>

</div>