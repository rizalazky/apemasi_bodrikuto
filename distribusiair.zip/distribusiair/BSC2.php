<div class="context">
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 121px; left: 1263px; background-color: rgb(2, 255, 90); color: rgb(102, 102, 102); width: 15px; height: 15px;">

  </div>
  <div class="bahan panah" data-rot="90" style="position: absolute; top: 1220px; left: -331px; transform: rotate(90deg); width: 2000px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 131px; left: 1177px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 221px; left: 667px; transform: rotate(360deg); width: 600px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 213px; left: 1264px; background-color: rgb(255, 188, 4); width: 15px; height: 15px;">

  </div>


  <div class="bahan panah" data-rot="0" style="position: absolute; top: 362px; left: 1224px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="90" style="position: absolute; top: 245px; left: 1130px; transform: rotate(90deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1174px; left: 214px; width: 500px;">

  </div>
  <div class="bahan panah" data-rot="90" style="position: absolute; top: 1468px; left: -151px; transform: rotate(90deg); width: 2850px;">

  </div>



  <div class="bahan panah" data-rot="90" style="position: absolute; top: 246px; left: 997px; width: 50px; transform: rotate(90deg);">

  </div>
  <div class="bahan panah" data-rot="90" style="position: absolute; top: 244px; left: 858px; transform: rotate(90deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="90" style="position: absolute; top: 245px; left: 716px; width: 50px; transform: rotate(90deg);">

  </div>


  <div class="bahan panah" data-rot="0" style="position: absolute; top: 360px; left: 669px; width: 50px;">

  </div>




  <div class="bahan panah" data-rot="0" style="position: absolute; top: 445px; left: 670px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 540px; left: 671px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 635px; left: 670px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 736px; left: 669px; width: 50px;">

  </div>





  <div class="bahan panah" data-rot="0" style="position: absolute; top: 833px; left: 670px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 919px; left: 620px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1082px; left: 669px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 996px; left: 670px; width: 50px;">

  </div>

  <div class="bahan panah" data-rot="90" style="position: absolute; top: 1198px; left: 441px; width: 50px; transform: rotate(90deg);">

  </div>

  <div class="bahan panah" data-rot="90" style="position: absolute; top: 1632px; left: -244px; width: 920px; transform: rotate(90deg);">

  </div>

  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1330px; left: 620px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1332px; left: 216px; width: 50px;">

  </div>








  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1436px; left: 217px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1540px; left: 217px; width: 51px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1648px; left: 217px; width: 51px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1760px; left: 217px; width: 51px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1865px; left: 217px; width: 51px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1975px; left: 217px; width: 51px;">

  </div>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 2093px; left: 174px; width: 80px;">


  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1164px; left: 660px; background-color: rgb(213, 1, 1); height: 15px; width: 15px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 120px; left: 1069px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 357px; left: 1112px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;" selected="true">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 268px; left: 1095px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;" selected="true">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;" selected="true">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 268px; left: 962px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;" selected="true">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 267px; left: 825px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;" selected="true">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 266px; left: 685px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;" selected="true">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 350px; left: 714px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;" selected="true">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 440px; left: 714px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;" selected="true">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 532px; left: 714px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;" selected="true">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 628px; left: 713px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;" selected="true">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 730px; left: 715px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;" selected="true">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 826px; left: 717px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;" selected="true">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 909px; left: 513px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;" selected="true">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 988px; left: 716px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;" selected="true">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1069px; left: 714px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;" selected="true">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1165px; left: 709px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;" selected="true">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1220px; left: 410px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;" selected="true">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1322px; left: 258px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;" selected="true">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1427px; left: 255px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;" selected="true">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1533px; left: 253px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;" selected="true">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1639px; left: 254px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;" selected="true">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1750px; left: 251px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;" selected="true">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1859px; left: 249px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;" selected="true">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1968px; left: 248px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;" selected="true">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2089px; left: 247px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;" selected="true">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1327px; left: 508px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;" selected="true">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1425px; left: 715px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;" selected="true">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1436px; left: 668px; width: 50px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1532px; left: 504px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;" selected="true">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1539px; left: 618px; width: 50px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1638px; left: 505px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;" selected="true">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1647px; left: 618px; width: 50px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1748px; left: 504px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;" selected="true">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1755px; left: 618px; width: 50px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1856px; left: 504px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;" selected="true">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1865px; left: 618px; width: 50px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2087px; left: 60px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;" selected="true">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 1979px; left: 617px; width: 50px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1973px; left: 503px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;" selected="true">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2085px; left: 505px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;" selected="true">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 2091px; left: 619px; width: 50px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2212px; left: 508px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;" selected="true">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2213px; left: 713px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;" selected="true">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 2219px; left: 621px;">

  </div>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 464px; left: 1112px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;" selected="true">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 568px; left: 1111px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;" selected="true">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 669px; left: 1112px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;" selected="true">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 770px; left: 1110px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;" selected="true">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 882px; left: 1114px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;" selected="true">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 990px; left: 1111px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;" selected="true">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1105px; left: 1110px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;" selected="true">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1220px; left: 1111px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;" selected="true">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1342px; left: 1112px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;" selected="true">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1459px; left: 1111px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;" selected="true">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1578px; left: 1110px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;" selected="true">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1696px; left: 1113px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;" selected="true">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2744px; left: 1111px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;" selected="true">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2617px; left: 1113px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;" selected="true">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2490px; left: 1109px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;" selected="true">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>

  <table class="bahan table" data-rot="0" style="position: absolute; top: 2370px; left: 1108px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;" selected="true">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2272px; left: 1112px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;" selected="true">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2170px; left: 1111px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;" selected="true">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2038px; left: 1109px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;" selected="true">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1917px; left: 1110px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;" selected="true">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 1802px; left: 1110px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;" selected="true">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <table class="bahan table" data-rot="0" style="position: absolute; top: 2872px; left: 1112px;">
    <thead>
      <tr>
        <th colspan="2">
          <select name="lokasi" class="lokasi">
            <option value="CSc. 1 Ka" style="text-align:center;" selected="true">CSc. 1 Ka
            </option>
            <option value="CSc.Ki. 1 Ka" style="text-align:center;">CSc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 2 Ka" style="text-align:center;">CSc.Ki. 2 Ka
            </option>
            <option value="CSc.Ki. 3 Ka" style="text-align:center;">CSc.Ki. 3 Ka
            </option>
            <option value="CSc.Ki. 4 Ka" style="text-align:center;">CSc.Ki. 4 Ka
            </option>
            <option value="Sc.Ki. 1 Ka" style="text-align:center;">Sc.Ki. 1 Ka
            </option>
            <option value="CSc.Ki. 5 Ka" style="text-align:center;">CSc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki. 6 Ka" style="text-align:center;">CSc.Ki. 6 Ka
            </option>
            <option value="CSc.Ki. 7 Ka" style="text-align:center;">CSc.Ki. 7 Ka
            </option>
            <option value="CSc.Ki. 8 Ka" style="text-align:center;">CSc.Ki. 8 Ka
            </option>
            <option value="Sc.Ki. 2 Ka" style="text-align:center;">Sc.Ki. 2 Ka
            </option>
            <option value="Sc.Ki. 3 Ka" style="text-align:center;">Sc.Ki. 3 Ka
            </option>
            <option value="Sc.Ki. 4 Ka" style="text-align:center;">Sc.Ki. 4 Ka
            </option>
            <option value="CSc.Ki. 9 Ka" style="text-align:center;">CSc.Ki. 9 Ka
            </option>
            <option value="CSc.Ki. 10 Ka" style="text-align:center;">CSc.Ki. 10 Ka
            </option>
            <option value="CSc.Ki. 11 Ka" style="text-align:center;">CSc.Ki. 11 Ka
            </option>
            <option value="CSc.Ki. 12 Ka" style="text-align:center;">CSc.Ki. 12 Ka
            </option>
            <option value="CSc.Ki. 13 Ka" style="text-align:center;">CSc.Ki. 13 Ka
            </option>
            <option value="CSc.Ki. 14 Ka" style="text-align:center;">CSc.Ki. 14 Ka
            </option>
            <option value="CSc.Ki. 15 Ka" style="text-align:center;">CSc.Ki. 15 Ka
            </option>
            <option value="Sc.Ki. 5 Ka" style="text-align:center;">Sc.Ki. 5 Ka
            </option>
            <option value="CSc.Ki.16 Ka" style="text-align:center;">CSc.Ki.16 Ka
            </option>
            <option value="CSc.Ki.17 Ka" style="text-align:center;">CSc.Ki.17 Ka
            </option>
            <option value="Sc.Ki. 6 Ka" style="text-align:center;" selected="true">Sc.Ki. 6 Ka
            </option>
            <option value="CSc.Ka. 1 Ki" style="text-align:center;">CSc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 2 Ki" style="text-align:center;">CSc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 3 Ki" style="text-align:center;">CSc.Ka. 3 Ki
            </option>
            <option value="CSc.Ka. 4 Ki" style="text-align:center;">CSc.Ka. 4 Ki
            </option>
            <option value="CSc.Ka. 5 Ki" style="text-align:center;">CSc.Ka. 5 Ki
            </option>
            <option value="CSc.Ka. 6 Ki" style="text-align:center;">CSc.Ka. 6 Ki
            </option>
            <option value="CSc.Ka. 7 Ki" style="text-align:center;">CSc.Ka. 7 Ki
            </option>
            <option value="CSc.Ka. 8 Ki" style="text-align:center;">CSc.Ka. 8 Ki
            </option>
            <option value="CSc.Ka. 9 Ki" style="text-align:center;">CSc.Ka. 9 Ki
            </option>
            <option value="Sc.Ka. 1 Ki" style="text-align:center;">Sc.Ka. 1 Ki
            </option>
            <option value="CSc.Ka. 10 Ka" style="text-align:center;">CSc.Ka. 10 Ka
            </option>
            <option value="Sc.Ka. 2 Ki" style="text-align:center;">Sc.Ka. 2 Ki
            </option>
            <option value="CSc.Ka. 11 Ki" style="text-align:center;">CSc.Ka. 11 Ki
            </option>
            <option value="Sc.Ka. 3 Ki" style="text-align:center;">Sc.Ka. 3 Ki
            </option>
            <option value="Cr.GL. 1 Ka" style="text-align:center;">Cr.GL. 1 Ka
            </option>
            <option value="GL. 1 Ki" style="text-align:center;">GL. 1 Ki
            </option>
            <option value="GL. 2 Ka" style="text-align:center;">GL. 2 Ka
            </option>
            <option value="Cr.GL. 2 Ka" style="text-align:center;">Cr.GL. 2 Ka
            </option>
            <option value="GL. 3 Ka" style="text-align:center;">GL. 3 Ka
            </option>
            <option value="Cr.GL. 3 Ka" style="text-align:center;">Cr.GL. 3 Ka
            </option>
            <option value="GL. 4 Ka" style="text-align:center;">GL. 4 Ka
            </option>
            <option value="GL. 5 Ka" style="text-align:center;">GL. 5 Ka
            </option>
            <option value="GL. 6 Ka" style="text-align:center;">GL. 6 Ka
            </option>
            <option value="GL. 6 Ki" style="text-align:center;">GL. 6 Ki
            </option>
            <option value="CKd. 1 ki" style="text-align:center;">CKd. 1 ki
            </option>
            <option value="CKd. 2 ki" style="text-align:center;">CKd. 2 ki
            </option>
            <option value="CKd. 3 ki" style="text-align:center;">CKd. 3 ki
            </option>
            <option value="Kd. 1 ki" style="text-align:center;">Kd. 1 ki
            </option>
            <option value="CKd. 4 ki" style="text-align:center;">CKd. 4 ki
            </option>
            <option value="CKd. 5 ki" style="text-align:center;">CKd. 5 ki
            </option>
            <option value="CKd. 6 ki" style="text-align:center;">CKd. 6 ki
            </option>
            <option value="CKd. 7 ki" style="text-align:center;">CKd. 7 ki
            </option>
            <option value="Kd. 2 ki" style="text-align:center;">Kd. 2 ki
            </option>
            <option value="Kd. 2 ka" style="text-align:center;">Kd. 2 ka
              <!-- <option value="satu">Satu</option>
                  <option value="Dua" selected>Dua</option>
                  <option value="Tiga">Tiga</option> -->
            </option>
          </select>
        </th>
      </tr>
    </thead>
    <tbody class="tbody">
      <tr>
        <td>Area</td>
        <td></td>
      </tr>
      <tr>
        <td>Q Alir</td>
        <td></td>
      </tr>

    </tbody>
  </table>
  <div class="bahan panah" data-rot="0" style="position: absolute; top: 470px; left: 1222px; width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 577px; left: 1222px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 677px; left: 1222px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 778px; left: 1221px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 888px; left: 1223px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1000px; left: 1222px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1115px; left: 1223px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1230px; left: 1223px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1351px; left: 1225px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1465px; left: 1222px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1587px; left: 1224px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1708px; left: 1224px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1811px; left: 1224px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 1928px; left: 1222px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2049px; left: 1222px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2181px; left: 1221px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2281px; left: 1221px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2381px; left: 1221px; transform: rotate(360deg); width: 50px;">

  </div>

  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2499px; left: 1221px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2626px; left: 1224px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2750px; left: 1223px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan panah" data-rot="360" style="position: absolute; top: 2881px; left: 1221px; transform: rotate(360deg); width: 50px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 301px; left: 288px; background-color: rgb(0, 247, 255);">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 332px; left: 288px; background-color: rgb(255, 0, 0);">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 367px; left: 288px; background-color: rgb(255, 188, 4);">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 401px; left: 288px; background-color: rgb(0, 255, 89);">

  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 325px; left: 311px;"><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700;">Bangunan Bagi Sadap</span></div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 296px; left: 310px;"><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700;">Bangunan Sadap</span></div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 359px; left: 313px;"><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700;">Bangunan Bagi</span></div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 390px; left: 314px; color: rgb(0, 0, 0);"><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700;">Bangunan Corong&nbsp;</span><span style="color: rgb(213, 213, 213); font-family: Consolas, &quot;Lucida Console&quot;, &quot;Courier New&quot;, monospace; font-size: 12px; white-space: nowrap;">2, 255, 90</span><br></div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 209px; left: 1145px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 211px; left: 1011px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>

  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 625px; left: 659px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 532px; left: 658px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 435px; left: 657px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 350px; left: 658px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 210px; left: 732px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 210px; left: 873px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 726px; left: 658px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <!--  sadap -->
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 824px; left: 658px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <!-- corong -->
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 911px; left: 658px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 988px; left: 659px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1073px; left: 660px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1164px; left: 457px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1321px; left: 204px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1426px; left: 204px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1638px; left: 205px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1531px; left: 207px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1750px; left: 204px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1855px; left: 205px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1966px; left: 206px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2084px; left: 206px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1321px; left: 658px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1427px; left: 659px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1528px; left: 658px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1638px; left: 658px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1744px; left: 659px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1857px; left: 659px; background-color: rgb(2, 255, 90); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1969px; left: 661px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2082px; left: 659px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2208px; left: 660px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>

  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 351px; left: 1263px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 460px; left: 1263px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 568px; left: 1264px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 668px; left: 1265px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 769px; left: 1264px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 878px; left: 1264px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 988px; left: 1262px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1108px; left: 1263px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>

  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1219px; left: 1263px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1341px; left: 1264px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1457px; left: 1264px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1577px; left: 1264px; background-color: rgb(0, 247, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1695px; left: 1262px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1802px; left: 1263px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 1919px; left: 1262px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2039px; left: 1263px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2172px; left: 1261px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2273px; left: 1262px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2370px; left: 1263px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2489px; left: 1263px; background-color: rgb(49, 249, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2616px; left: 1264px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2739px; left: 1265px; background-color: rgb(38, 255, 113); height: 15px; width: 15px;">

  </div>
  <div class="bahan bulet animated" data-rot="0" style="position: absolute; top: 2873px; left: 1263px; background-color: rgb(49, 249, 255); height: 15px; width: 15px;">

  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 117px; left: 1284px; color: rgb(255, 0, 0); width: 70px;">CSc. 1
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 208px; left: 1285px; color: rgb(255, 0, 0); width: 70px;">
    BSc. 1
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 346px; left: 1286px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 1
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 456px; left: 1285px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 2
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 563px; left: 1284px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 3
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 664px; left: 1283px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 4
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 765px; left: 1285px; color: rgb(255, 0, 0); width: 70px;">
    BSc.Ki. 1
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 877px; left: 1285px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 5
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 983px; left: 1284px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 6
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1105px; left: 1285px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 7
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1217px; left: 1285px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 8
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1338px; left: 1286px; color: rgb(255, 0, 0); width: 70px;">
    BSc.Ki. 2
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1453px; left: 1286px; color: rgb(255, 0, 0); width: 70px;">
    BSc.Ki. 3
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1573px; left: 1287px; color: rgb(255, 0, 0); width: 70px;">
    BSc.Ki. 4
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1691px; left: 1284px; color: rgb(255, 0, 0); width: 70px;">
    CSc.Ki. 9
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1799px; left: 1283px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 10
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1915px; left: 1281px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 11
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2037px; left: 1283px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 12
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2169px; left: 1284px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 13
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2269px; left: 1284px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 14
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2369px; left: 1284px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 15
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2483px; left: 1284px; color: rgb(255, 0, 0); width: 80px;">
    BSc.Ki. 5
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2612px; left: 1285px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 16
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2736px; left: 1285px; color: rgb(255, 0, 0); width: 80px;">
    CSc.Ki. 17
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2869px; left: 1282px; color: rgb(255, 0, 0); width: 80px;">
    BSc.Ki. 6
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 184px; left: 1121px; color: rgb(255, 0, 0);">
    CSc.Ka. 1
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 186px; left: 987px; color: rgb(255, 0, 0);">
    CSc.Ka. 2
  </div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 186px; left: 848px; color: rgb(255, 0, 0);">
    CSc.Ka. 3</div>
  <div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 186px; left: 706px; color: rgb(255, 0, 0);">
    CSc.Ka. 4</div>
  <div class="bahan text" contenteditable="true" data-rot="810" style="position: absolute; top: 135px; left: 1255px; color: rgb(0, 8, 255); transform: rotate(810deg); width: 200px;">
    SALURAN INDUK SUCEN
  </div>
  <div class="bahan text" contenteditable="true" data-rot="810" style="position: absolute; top: 1205px; left: 1279px; color: rgb(0, 8, 255); transform: rotate(810deg); width: 200px;">
    SALURAN SEKUNDER SUCEN KIRI
  </div>
<div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 344px; left: 581px; color: rgb(255, 0, 0);">
          CSc.Ka. 5
        </div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 431px; left: 582px; color: rgb(255, 0, 0);">
          CSc.Ka. 6</div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 527px; left: 583px; color: rgb(255, 0, 0);">
          CSc.Ka. 7</div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 622px; left: 583px; color: rgb(255, 0, 0);">
          CSc.Ka. 8</div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 722px; left: 581px; color: rgb(255, 0, 0);">
          CSc.Ka. 9</div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 820px; left: 580px; color: rgb(255, 5, 5);">
          BSc.Ka. 1 
        </div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 986px; left: 580px; color: rgb(231, 13, 13);">
          BSc.Ka. 2</div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 907px; left: 683px;"><span style="color: rgb(236, 19, 19);">CSc.Ka. 10</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1070px; left: 577px;"><span style="color: rgb(236, 19, 19);">CSc.Ka. 11</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1189px; left: 591px; color: rgb(233, 1, 1);">
          BSc.Ka. 3 
        </div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1139px; left: 443px; color: rgb(255, 0, 0);">
          CKd. 1
        </div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1315px; left: 147px; color: rgb(255, 0, 0);"><span style="color: rgb(226, 24, 24);">CKd. 2</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1423px; left: 147px;"><span style="color: rgb(226, 24, 24);">CKd. 3</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1527px; left: 149px;"><span style="color: rgb(226, 24, 24);">BKd. 1</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1635px; left: 148px;"><span style="color: rgb(226, 24, 24);">CKd. 4</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1745px; left: 149px;"><span style="color: rgb(226, 24, 24);">CKd. 5</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1850px; left: 150px;"><span style="color: rgb(226, 24, 24);">CKd. 6</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1962px; left: 149px;"><span style="color: rgb(226, 24, 24);">CKd. 7</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2106px; left: 186px;"><span style="color: rgb(226, 24, 24);">BKd. 2</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1317px; left: 680px;"><font color="#e90101">Cr.GL.1</font></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1422px; left: 600px;"><span style="color: rgb(233, 1, 1);">BGL.1</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1523px; left: 679px;"><span style="color: rgb(233, 1, 1);">BGL.2</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1634px; left: 680px;"><span style="color: rgb(233, 1, 1);">Cr.GL.2</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1741px; left: 682px;"><span style="color: rgb(233, 1, 1);">BGL.2</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1853px; left: 679px;"><span style="color: rgb(233, 1, 1);">Cr.GL.3</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 1965px; left: 682px;"><span style="color: rgb(233, 1, 1);">BGL.4</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2078px; left: 679px;"><span style="color: rgb(233, 1, 1);">BGL.5</span></div><div class="bahan text" contenteditable="true" data-rot="0" style="position: absolute; top: 2231px; left: 644px;"><span style="color: rgb(233, 1, 1);">BGL.6</span></div><div class="bahan text" contenteditable="true" data-rot="90" style="position: absolute; top: 1749px; left: 668px; color: rgb(1, 29, 239); transform: rotate(90deg);">
          SALURAN SEKUNDER GILING
        </div><div class="bahan text" contenteditable="true" data-rot="270" style="position: absolute; top: 1752px; left: -25px; color: rgb(0, 30, 255); transform: rotate(270deg);">
          SALURAN SEKUNDER KADIREJO
        </div>
        <div class="bahan text" id="nl1" data-nilaiid="" data-qberikan="Kd. 2 ka,Kd. 2 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 2026px; left: 154px;">
          </div><div class="bahan text" id="nl2" data-nilaiid="nl1" data-qberikan="CKd. 7 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1910px; left: 152px;">
          </div><div class="bahan text" id="nl3" data-nilaiid="nl2" data-qberikan="CKd. 6 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1796px; left: 152px;">
          Nilai 3</div><div class="bahan text" id="nl4" data-nilaiid="nl3" data-qberikan="CKd. 5 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1688px; left: 150px;">
          Nilai 4</div><div class="bahan text" id="nl5" data-nilaiid="nl4" data-qberikan="CKd. 4 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1576px; left: 148px;">
          Nilai 5</div><div class="bahan text" id="nl6" data-nilaiid="nl5" data-qberikan="Kd. 1 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1474px; left: 146px;">
          Nilai 6</div><div class="bahan text" id="nl7" data-nilaiid="nl6" data-qberikan="CKd. 3 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1366px; left: 150px;">
          Nilai 7</div><div class="bahan text" id="nl8" data-nilaiid="nl7" data-qberikan="CKd. 2 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1136px; left: 256px;">
          Nilai 8</div><div class="bahan text" id="nl9" data-nilaiid="nl8" data-qberikan="CKd. 1 ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1136px; left: 546px;">
          Nilai 9</div><div class="bahan text" id="nl10" data-nilaiid="" data-qberikan="GL. 6 Ka,GL. 6 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 2152px; left: 678px;">
          Nilai 10</div><div class="bahan text" id="nl11" data-nilaiid="nl10" data-qberikan="GL. 5 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2018px; left: 682px;">
          Nilai 11</div><div class="bahan text" id="nl12" data-nilaiid="nl11" data-qberikan="GL. 4 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1908px; left: 680px;">
          Nilai 12</div><div class="bahan text" id="nl13" data-nilaiid="nl12" data-qberikan="Cr.GL. 3 Ka" data-sum="cr1,cr2" contenteditable="true" data-rot="0" style="position: absolute; top: 1796px; left: 682px;">
          Nilai 13</div><div class="bahan text" id="nl14" data-nilaiid="nl13" data-qberikan="GL. 3 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1684px; left: 680px;">
          Nilai 14</div><div class="bahan text" id="nl15" data-nilaiid="nl14" data-qberikan="Cr.GL. 2 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1578px; left: 680px;">
          Nilai 15</div><div class="bahan text" id="nl16" data-nilaiid="nl15" data-qberikan="GL. 2 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1468px; left: 592px;">
          Nilai 16</div><div class="bahan text" id="nl17" data-nilaiid="nl16" data-qberikan="GL. 1 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1368px; left: 684px;">
          Nilai 17</div><div class="bahan text" id="nl18" data-nilaiid="nl17" data-qberikan="Cr.GL. 1 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1230px; left: 598px;">
          Nilai 18</div><div class="bahan text" id="nl19" data-nilaiid="nl9,nl18" data-qberikan="Sc.Ka. 3 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1104px; left: 594px;">
          Nilai 19</div><div class="bahan text" id="nl20" data-nilaiid="nl19" data-qberikan="CSc.Ka. 11 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 1026px; left: 592px;">
          Nilai 20</div><div class="bahan text" id="nl21" data-nilaiid="nl20" data-qberikan="Sc.Ka. 2 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 940px; left: 686px;">
          Nilai 21</div><div class="bahan text" id="nl22" data-nilaiid="nl21" data-qberikan="CSc.Ka. 10 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 856px; left: 594px;">
          Nilai 22</div><div class="bahan text" id="nl23" data-nilaiid="nl22" data-qberikan="Sc.Ka. 1 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 763px; left: 592px;">
          Nilai 23</div><div class="bahan text" id="nl24" data-nilaiid="nl23" data-qberikan="CSc.Ka. 9 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 674px; left: 592px;">
          Nilai 24</div><div class="bahan text" id="nl25" data-nilaiid="nl24" data-qberikan="CSc.Ka. 8 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 577px; left: 594px;">
          Nilai 25</div><div class="bahan text" id="nl26" data-nilaiid="nl25" data-qberikan="CSc.Ka. 7 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 481px; left: 593px;">
          Nilai 26</div><div class="bahan text" id="nl27" data-nilaiid="nl26" data-qberikan="CSc.Ka. 6 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 389px; left: 594px;">
          Nilai 27</div><div class="bahan text" id="nl28" data-nilaiid="nl27" data-qberikan="CSc.Ka. 5 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 293px; left: 596px;">
          Nilai 28</div><div class="bahan text" id="nl29" data-nilaiid="nl28" data-qberikan="CSc.Ka. 4 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 231px; left: 786px;">
          Nilai 29</div><div class="bahan text" id="nl30" data-nilaiid="nl29" data-qberikan="CSc.Ka. 3 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 232px; left: 925px;">
          Nilai 30</div><div class="bahan text" id="nl31" data-nilaiid="nl30" data-qberikan="CSc.Ka. 2 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 230px; left: 1058px;">
          Nilai 31</div><div class="bahan text" id="nl32" data-nilaiid="nl31" data-qberikan="CSc.Ka. 1 Ki" contenteditable="true" data-rot="0" style="position: absolute; top: 231px; left: 1190px;">
          Nilai 32</div><div class="bahan text" id="nl33" data-nilaiid="" data-qberikan="Sc.Ki. 6 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2803px; left: 1283px;">
          Nilai 33</div><div class="bahan text" id="nl34" data-nilaiid="nl33" data-qberikan="CSc.Ki.17 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2672px; left: 1284px;">
          Nilai 34</div><div class="bahan text" id="nl35" data-nilaiid="nl34" data-qberikan="CSc.Ki.16 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2542px; left: 1284px;">
          Nilai 35</div><div class="bahan text" id="nl36" data-nilaiid="nl35" data-qberikan="Sc.Ki. 5 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2426px; left: 1286px;">
          Nilai 36</div><div class="bahan text" id="nl37" data-nilaiid="nl36" data-qberikan="CSc.Ki. 15 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2314px; left: 1285px;">
          Nilai 37</div><div class="bahan text" id="nl38" data-nilaiid="nl37" data-qberikan="CSc.Ki. 14 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2218px; left: 1285px;">
          Nilai 38</div><div class="bahan text" id="nl39" data-nilaiid="nl38" data-qberikan="CSc.Ki. 13 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 2099px; left: 1287px;">
          Nilai 39</div><div class="bahan text" id="nl40" data-nilaiid="nl39" data-qberikan="CSc.Ki. 12 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1970px; left: 1287px;">
          Nilai 41</div><div class="bahan text" id="nl41" data-nilaiid="nl40" data-qberikan="CSc.Ki. 11 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1855px; left: 1290px;">
          Nilai 42</div><div class="bahan text" id="nl42" data-nilaiid="nl41" data-qberikan="CSc.Ki. 10 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1744px; left: 1290px;">
          Nilai 43</div><div class="bahan text" id="nl43" data-nilaiid="nl42" data-qberikan="CSc.Ki. 9 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1630px; left: 1290px;">
          Nilai 44</div><div class="bahan text" id="nl44" data-nilaiid="nl43" data-qberikan="Sc.Ki. 4 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1508px; left: 1289px;">
          Nilai 45</div><div class="bahan text" id="nl45" data-nilaiid="nl44" data-qberikan="Sc.Ki. 3 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1391px; left: 1290px;">
          Nilai 46</div><div class="bahan text" id="nl46" data-nilaiid="nl45" data-qberikan="Sc.Ki. 2 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1272px; left: 1289px;">
          Nilai 47</div><div class="bahan text" id="nl47" data-nilaiid="nl46" data-qberikan="CSc.Ki. 8 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1157px; left: 1287px;">
          Nilai 48</div><div class="bahan text" id="nl48" data-nilaiid="nl47" data-qberikan="CSc.Ki. 7 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 1037px; left: 1289px;">
          Nilai 49</div><div class="bahan text" id="nl49" data-nilaiid="nl48" data-qberikan="CSc.Ki. 6 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 930px; left: 1288px;">
          Nilai 50</div><div class="bahan text" id="nl50" data-nilaiid="nl49" data-qberikan="CSc.Ki. 5 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 818px; left: 1289px;">
          Nilai 51</div><div class="bahan text" id="nl51" data-nilaiid="nl50" data-qberikan="Sc.Ki. 1 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 712px; left: 1290px;">
          Nilai 52</div><div class="bahan text" id="nl52" data-nilaiid="nl51" data-qberikan="CSc.Ki. 4 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 610px; left: 1289px;">
          Nilai 53</div><div class="bahan text" id="nl53" data-nilaiid="nl52" data-qberikan="CSc.Ki. 3 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 508px; left: 1289px;">
          Nilai 54</div><div class="bahan text" id="nl54" data-nilaiid="nl53" data-qberikan="CSc.Ki. 2 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 402px; left: 1288px;">
          Nilai 55</div><div class="bahan text" id="nl55" data-nilaiid="nl54" data-qberikan="CSc.Ki. 1 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 276px; left: 1287px;">
          Nilai 56</div><div class="bahan text" id="nl56" data-nilaiid="nl32,nl55" data-qberikan="" contenteditable="true" data-rot="0" style="position: absolute; top: 161px; left: 1281px;">
          Nilai 57</div><div class="bahan text" id="nl57" data-nilaiid="nl56" data-qberikan="CSc. 1 Ka" contenteditable="true" data-rot="0" style="position: absolute; top: 70px; left: 1207px;">
          Nilai 60</div></div>