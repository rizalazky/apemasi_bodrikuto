<div class="headerCSS">
      <div class="header__logoJateng">
        <img class="animate__animated animate__swing animate__infinite infinite" src="../assets/header/logo_jateng.png" alt="Logo" />
        <div class="header__title">
          <h1>APEMASI</h1>
          <span> BPSDA BODRI KUTO</span>
        </div>
      </div>

      <div class="header__logoPublikasi">
        <img src="../assets/header/gunung.png" alt="" srcset="" />
        <div class="header__title">
          <span class="publikasi_distibusi">
            <marquee scrollamount="15">
              PUBLIKASI DISTRIBUSI AIR IRIGASI</marquee>
          </span>
        </div>
      </div>

      <div class="header__logoJatengGayeng">
        <img class="animate__animated animate__flipInY" src="../assets//header//logoJatengGayeng.png" alt="" srcset="" />
      </div>
    </div>